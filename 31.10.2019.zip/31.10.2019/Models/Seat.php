<?php
/**
 * Created by PhpStorm.
 * User: banu
 * Date: 24/10/19
 * Time: 12:58 AM
 */

namespace Models;


use Connection\DB;
use Throwable;

class Seat
{
    private $table = 't_seats';
    private $fields = ['seat_id','seat_category','status'];

    public static function all(){
        try{
            $stmt = DB::getConnection()->prepare("SELECT * FROM t_seats");
            $stmt->execute();
            $AllRows = [];
            while ($row = $stmt->fetch()){
                $AllRows[] = $row;
            }
            return $AllRows;
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function insert($data){
        try{
            $sql = "INSERT INTO t_seats (seat_category,number_of_seats,seat_status) VALUES (:seat_category,:number_of_seats,:seat_status)";
            $stmt= DB::getConnection()->prepare($sql);
          $stmt->execute([
                ':seat_category'=>$data['seatName'],                              
                ':number_of_seats'=>$data['numberOfSeats'],                              
                ':seat_status'=>$data['seatStatus']
            ]);
            return true;
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function select($seat_id){
        try{
            $stmt = DB::getConnection()->prepare("SELECT * FROM t_seats WHERE seat_id = :seat_id LIMIT 1");
            $stmt->execute([':seat_id' => $seat_id]);
            return $stmt->fetch();
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function update($data){
        try{
            $sql = "UPDATE t_seats SET seat_category=:seat_category WHERE seat_id=:seat_id";
            $stmt= DB::getConnection()->prepare($sql);
            $stmt->execute([':seat_category'=>$data['seatName'],':seat_id'=>$data['seatId']]);
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
    public static function delete($seat_id){
        try{
            $sql = 'DELETE FROM 
                        t_seats 
                    WHERE 
                        seat_id = :seat_id';
            $q = DB::getConnection()->prepare($sql);
            $q->execute([':seat_id' => $seat_id]);
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }
}
?>