<!DOCTYPE html>
<html>
<head>
	<title>Movie Ticket Booking System</title>
	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/style.css">
	<link rel="stylesheet" type="text/javascript" href="../Assets/backend/js/selectseats.js">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	 

</head>
<body onload="onLoaderFunc()">
  <div class="container-fluid">
    <div class="row">
    <nav class="navbar navbar-inverse navbar-static-top">
                  <!-- navbar starts here -->
        <div class="container-fluid">
          <div class="navbar-header">
              <a class="navbar-brand" href="#"><img src="../Assets/backend/images/logoct.png"></a>
              <span class="searchbar text-center">
              <input type="text" name="" class="searchbar" value="" placeholder="search movies"></span>
              <span class="search-btn"><button class="btn search-btn"><span class="glyphicon glyphicon-search "></span></button></span>
          </div>
          <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="#">Home</a></li>
            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Languages <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#" class="active">Tamil</a></li>
                <li><a href="#">English</a></li>
                <li><a href="#">Hindi</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Location <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#">Chennai</a></li>
                <li><a href="#">Vellore</a></li>
                <li><a href="#">kancheepuram</a></li>
              </ul>
            </li>
            
            <li>
              <div class="container-m menu-icon dropbtn" onclick="menu(this)" >
              <div class="bar1"></div>
              <div class="bar2"></div>
              <div class="bar3"></div>
          </div>
          
            </li>
          </ul>
          <div id="myDropdown" class="dropdown-content">
              <a href="#home">Home</a>
              <a href="#about"><span class="glyphicon glyphicon-cog">Settings </span> </a>
              <a href="#contact">Contact</a>
        </div>
      </div>

    </nav>        <!-- navbar ends here  -->
    </div>
                <!-- seat selection starts here  -->
        <div class="inputForm">
            <center>
                Name *: <input type="text" id="Username" required>
                Number of Seats *: <input type="number" id="Numseats" required>
              <br/><br/>
              <button onclick="takeData()" class="btn-warning">Start Selecting</button>
            </center>
        </div>
  

    <div class="seatStructure">
        <center>
    <div class="row"  >
  
    <table id="seatsBlock" class="tableStructure" width="100%" >
         <p id="notification"></p>

  
          <tr>
            <td></td>
            <td>1</td>
            <td>2</td>
            <td>3</td>
            <td>4</td>
            <td>5</td>
            <td>6</td>
            <td>7</td>
            <td></td>
            <td>8</td>
            <td>9</td>
            <td>10</td>
            <td>11</td>
            <td>12</td>
            <td>13</td>
            <td>14</td>
            <td></td>
            <td>15</td>
            <td>16</td>
            <td>17</td>
            <td>18</td>
            <td>19</td>
            <td>20</td>
        </tr>
        <tr>
            <td colspan="21">First class </td>
        </tr>
          
        <tr>
            <td>A</td>
            <td><input type="checkbox" class="seats" value="A1"></td> 
            <td><input type="checkbox" class="seats" value="A2"></td> 
            <td><input type="checkbox" class="seats" value="A3"></td> 
            <td><input type="checkbox" class="seats" value="A4"></td> 
            <td><input type="checkbox" class="seats" value="A5"></td> 
            <td><input type="checkbox" class="seats" value="A6"></td> 
            <td><input type="checkbox" class="seats" value="A7"></td> 
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="A8"></td> 
            <td><input type="checkbox" class="seats" value="A9"></td> 
            <td><input type="checkbox" class="seats" value="A10"></td> 
            <td><input type="checkbox" class="seats" value="A11"></td> 
            <td><input type="checkbox" class="seats" value="A12"></td> 
            <td><input type="checkbox" class="seats" value="A13"></td> 
            <td><input type="checkbox" class="seats" value="A14"></td> 
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="A15"></td> 
            <td><input type="checkbox" class="seats" value="A16"></td> 
            <td><input type="checkbox" class="seats" value="A17"></td> 
            <td><input type="checkbox" class="seats" value="A18"></td> 
            <td><input type="checkbox" class="seats" value="A19"></td> 
            <td><input type="checkbox" class="seats" value="A20"></td> 
          </tr>
          
          <tr>
            <td>B</td>
            <td><input type="checkbox" class="seats" value="B1"></td>
            <td><input type="checkbox" class="seats" value="B2"></td>
            <td><input type="checkbox" class="seats" value="B3"></td>
            <td><input type="checkbox" class="seats" value="B4"></td>
            <td><input type="checkbox" class="seats" value="B5"></td>
            <td><input type="checkbox" class="seats" value="B6"></td>
            <td><input type="checkbox" class="seats" value="B7"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="B8"></td>
            <td><input type="checkbox" class="seats" value="B9"></td>
            <td><input type="checkbox" class="seats" value="B10"></td>
            <td><input type="checkbox" class="seats" value="B11"></td>
            <td><input type="checkbox" class="seats" value="B12"></td>
            <td><input type="checkbox" class="seats" value="B13"></td>
            <td><input type="checkbox" class="seats" value="B14"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="B15"></td>
            <td><input type="checkbox" class="seats" value="B16"></td>
            <td><input type="checkbox" class="seats" value="B17"></td>
            <td><input type="checkbox" class="seats" value="B18"></td>
            <td><input type="checkbox" class="seats" value="B19"></td>
            <td><input type="checkbox" class="seats" value="B20"></td>
          </tr>
            <tr class="seatVGap"></tr>
            <tr>
            <td colspan="21">Second class </td>
        </tr>
          <tr>
            <td>C</td>
            <td><input type="checkbox" class="seats" value="C1"></td>
            <td><input type="checkbox" class="seats" value="C2"></td>
            <td><input type="checkbox" class="seats" value="C3"></td>
            <td><input type="checkbox" class="seats" value="C4"></td>
            <td><input type="checkbox" class="seats" value="C5"></td>
            <td><input type="checkbox" class="seats" value="C6"></td>
            <td><input type="checkbox" class="seats" value="C7"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="C8"></td>
            <td><input type="checkbox" class="seats" value="C9"></td>
            <td><input type="checkbox" class="seats" value="C10"></td>
            <td><input type="checkbox" class="seats" value="C11"></td>
            <td><input type="checkbox" class="seats" value="C12"></td>
            <td><input type="checkbox" class="seats" value="C13"></td>
            <td><input type="checkbox" class="seats" value="C14"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="C15"></td>
            <td><input type="checkbox" class="seats" value="C16"></td>
            <td><input type="checkbox" class="seats" value="C17"></td>
            <td><input type="checkbox" class="seats" value="C18"></td>
            <td><input type="checkbox" class="seats" value="C19"></td>
            <td><input type="checkbox" class="seats" value="C20"></td>
          </tr>
          
        <tr>
            <td>D</td>
            <td><input type="checkbox" class="seats" value="D1"></td>
            <td><input type="checkbox" class="seats" value="D2"></td>
            <td><input type="checkbox" class="seats" value="D3"></td>
            <td><input type="checkbox" class="seats" value="D4"></td>
            <td><input type="checkbox" class="seats" value="D5"></td>
            <td><input type="checkbox" class="seats" value="D6"></td>
            <td><input type="checkbox" class="seats" value="D7"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="D8"></td>
            <td><input type="checkbox" class="seats" value="D9"></td>
            <td><input type="checkbox" class="seats" value="D10"></td>
            <td><input type="checkbox" class="seats" value="D11"></td>
            <td><input type="checkbox" class="seats" value="D12"></td>
            <td><input type="checkbox" class="seats" value="D13"></td>
            <td><input type="checkbox" class="seats" value="D14"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="D15"></td>
            <td><input type="checkbox" class="seats" value="D16"></td>
            <td><input type="checkbox" class="seats" value="D17"></td>
            <td><input type="checkbox" class="seats" value="D18"></td>
            <td><input type="checkbox" class="seats" value="D19"></td>
            <td><input type="checkbox" class="seats" value="D20"></td>
          </tr>
          
        <tr>
            <td>E</td>
            <td><input type="checkbox" class="seats" value="E1"></td>
            <td><input type="checkbox" class="seats" value="E2"></td>
            <td><input type="checkbox" class="seats" value="E3"></td>
            <td><input type="checkbox" class="seats" value="E4"></td>
            <td><input type="checkbox" class="seats" value="E5"></td>
            <td><input type="checkbox" class="seats" value="E6"></td>
            <td><input type="checkbox" class="seats" value="E7"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="E8"></td>
            <td><input type="checkbox" class="seats" value="E9"></td>
            <td><input type="checkbox" class="seats" value="E10"></td>
            <td><input type="checkbox" class="seats" value="E11"></td>
            <td><input type="checkbox" class="seats" value="E12"></td>
            <td><input type="checkbox" class="seats" value="E13"></td>
            <td><input type="checkbox" class="seats" value="E14"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="E15"></td>
            <td><input type="checkbox" class="seats" value="E16"></td>
            <td><input type="checkbox" class="seats" value="E17"></td>
            <td><input type="checkbox" class="seats" value="E18"></td>
            <td><input type="checkbox" class="seats" value="E19"></td>
            <td><input type="checkbox" class="seats" value="E20"></td>
          </tr>

          
        <tr class="seatVGap"></tr>
        <tr>
            <td colspan="21"class = " text-center">Third class </td>
        </tr>
          
        <tr>
            <td>F</td>
            <td><input type="checkbox" class="seats" value="F1"></td>
            <td><input type="checkbox" class="seats" value="F2"></td>
            <td><input type="checkbox" class="seats" value="F3"></td>
            <td><input type="checkbox" class="seats" value="F4"></td>
            <td><input type="checkbox" class="seats" value="F5"></td>
            <td><input type="checkbox" class="seats" value="F6"></td>
            <td><input type="checkbox" class="seats" value="F7"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="F8"></td>
            <td><input type="checkbox" class="seats" value="F9"></td>
            <td><input type="checkbox" class="seats" value="F10"></td>
            <td><input type="checkbox" class="seats" value="F11"></td>
            <td><input type="checkbox" class="seats" value="F12"></td>
            <td><input type="checkbox" class="seats" value="F13"></td>
            <td><input type="checkbox" class="seats" value="F14"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="F15"></td>
            <td><input type="checkbox" class="seats" value="F16"></td>
            <td><input type="checkbox" class="seats" value="F17"></td>
            <td><input type="checkbox" class="seats" value="F18"></td>
            <td><input type="checkbox" class="seats" value="F19"></td>
            <td><input type="checkbox" class="seats" value="F20"></td>
          </tr>
          
        <tr>
            <td>G</td>
            <td><input type="checkbox" class="seats" value="G1"></td>
            <td><input type="checkbox" class="seats" value="G2"></td>
            <td><input type="checkbox" class="seats" value="G3"></td>
            <td><input type="checkbox" class="seats" value="G4"></td>
            <td><input type="checkbox" class="seats" value="G5"></td>
            <td><input type="checkbox" class="seats" value="G6"></td>
            <td><input type="checkbox" class="seats" value="G7"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="G8"></td>
            <td><input type="checkbox" class="seats" value="G9"></td>
            <td><input type="checkbox" class="seats" value="G10"></td>
            <td><input type="checkbox" class="seats" value="G11"></td>
            <td><input type="checkbox" class="seats" value="G12"></td>
            <td><input type="checkbox" class="seats" value="G13"></td>
            <td><input type="checkbox" class="seats" value="G14"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="G15"></td>
            <td><input type="checkbox" class="seats" value="G16"></td>
            <td><input type="checkbox" class="seats" value="G17"></td>
            <td><input type="checkbox" class="seats" value="G18"></td>
            <td><input type="checkbox" class="seats" value="G19"></td>
            <td><input type="checkbox" class="seats" value="G20"></td>
          </tr>
          
        <tr>
            <td>H</td>
            <td><input type="checkbox" class="seats" value="H1"></td>
            <td><input type="checkbox" class="seats" value="H2"></td>
            <td><input type="checkbox" class="seats" value="H3"></td>
            <td><input type="checkbox" class="seats" value="H4"></td>
            <td><input type="checkbox" class="seats" value="H5"></td>
            <td><input type="checkbox" class="seats" value="H6"></td>
            <td><input type="checkbox" class="seats" value="H7"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="H8"></td>
            <td><input type="checkbox" class="seats" value="H9"></td>
            <td><input type="checkbox" class="seats" value="H10"></td>
            <td><input type="checkbox" class="seats" value="H11"></td>
            <td><input type="checkbox" class="seats" value="H12"></td>
            <td><input type="checkbox" class="seats" value="H13"></td>
            <td><input type="checkbox" class="seats" value="H14"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="H15"></td>
            <td><input type="checkbox" class="seats" value="H16"></td>
            <td><input type="checkbox" class="seats" value="H17"></td>
            <td><input type="checkbox" class="seats" value="H18"></td>
            <td><input type="checkbox" class="seats" value="H19"></td>
            <td><input type="checkbox" class="seats" value="H20"></td>
          </tr>
          
        <tr>
            <td>I</td>
            <td><input type="checkbox" class="seats" value="I1"></td>
            <td><input type="checkbox" class="seats" value="I2"></td>
            <td><input type="checkbox" class="seats" value="I3"></td>
            <td><input type="checkbox" class="seats" value="I4"></td>
            <td><input type="checkbox" class="seats" value="I5"></td>
            <td><input type="checkbox" class="seats" value="I6"></td>
            <td><input type="checkbox" class="seats" value="I7"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="I8"></td>
            <td><input type="checkbox" class="seats" value="I9"></td>
            <td><input type="checkbox" class="seats" value="I10"></td>
            <td><input type="checkbox" class="seats" value="I11"></td>
            <td><input type="checkbox" class="seats" value="I12"></td>
            <td><input type="checkbox" class="seats" value="I13"></td>
            <td><input type="checkbox" class="seats" value="I14"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="I15"></td>
            <td><input type="checkbox" class="seats" value="I16"></td>
            <td><input type="checkbox" class="seats" value="I17"></td>
            <td><input type="checkbox" class="seats" value="I18"></td>
            <td><input type="checkbox" class="seats" value="I19"></td>
            <td><input type="checkbox" class="seats" value="I20"></td>
          </tr>
          
        <tr>
            <td>J</td>
            <td><input type="checkbox" class="seats" value="J1"></td>
            <td><input type="checkbox" class="seats" value="J2"></td>
            <td><input type="checkbox" class="seats" value="J3"></td>
            <td><input type="checkbox" class="seats" value="J4"></td>
            <td><input type="checkbox" class="seats" value="J5"></td>
            <td><input type="checkbox" class="seats" value="J6"></td>
            <td><input type="checkbox" class="seats" value="J7"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="J8"></td>
            <td><input type="checkbox" class="seats" value="J9"></td>
            <td><input type="checkbox" class="seats" value="J10"></td>
            <td><input type="checkbox" class="seats" value="J11"></td>
            <td><input type="checkbox" class="seats" value="J12"></td>
            <td><input type="checkbox" class="seats" value="J13"></td>
            <td><input type="checkbox" class="seats" value="J14"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="J15"></td>
            <td><input type="checkbox" class="seats" value="J16"></td>
            <td><input type="checkbox" class="seats" value="J17"></td>
            <td><input type="checkbox" class="seats" value="J18"></td>
            <td><input type="checkbox" class="seats" value="J19"></td>
            <td><input type="checkbox" class="seats" value="J20"></td>
          </tr>
          <tr>
            <td>K</td>
            <td><input type="checkbox" class="seats" value="K1"></td>
            <td><input type="checkbox" class="seats" value="K2"></td>
            <td><input type="checkbox" class="seats" value="K3"></td>
            <td><input type="checkbox" class="seats" value="K4"></td>
            <td><input type="checkbox" class="seats" value="K5"></td>
            <td><input type="checkbox" class="seats" value="K6"></td>
            <td><input type="checkbox" class="seats" value="K7"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="K8"></td>
            <td><input type="checkbox" class="seats" value="K9"></td>
            <td><input type="checkbox" class="seats" value="K10"></td>
            <td><input type="checkbox" class="seats" value="K11"></td>
            <td><input type="checkbox" class="seats" value="K12"></td>
            <td><input type="checkbox" class="seats" value="K13"></td>
            <td><input type="checkbox" class="seats" value="K14"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="K15"></td>
            <td><input type="checkbox" class="seats" value="K16"></td>
            <td><input type="checkbox" class="seats" value="K17"></td>
            <td><input type="checkbox" class="seats" value="K18"></td>
            <td><input type="checkbox" class="seats" value="K19"></td>
            <td><input type="checkbox" class="seats" value="K20"></td>
          </tr>
          <tr>
            <td>L</td>
            <td><input type="checkbox" class="seats" value="L1"></td>
            <td><input type="checkbox" class="seats" value="L2"></td>
            <td><input type="checkbox" class="seats" value="L3"></td>
            <td><input type="checkbox" class="seats" value="L4"></td>
            <td><input type="checkbox" class="seats" value="L5"></td>
            <td><input type="checkbox" class="seats" value="L6"></td>
            <td><input type="checkbox" class="seats" value="L7"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="L8"></td>
            <td><input type="checkbox" class="seats" value="L9"></td>
            <td><input type="checkbox" class="seats" value="L10"></td>
            <td><input type="checkbox" class="seats" value="L11"></td>
            <td><input type="checkbox" class="seats" value="L12"></td>
            <td><input type="checkbox" class="seats" value="L13"></td>
            <td><input type="checkbox" class="seats" value="L14"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="L15"></td>
            <td><input type="checkbox" class="seats" value="L16"></td>
            <td><input type="checkbox" class="seats" value="L17"></td>
            <td><input type="checkbox" class="seats" value="L18"></td>
            <td><input type="checkbox" class="seats" value="L19"></td>
            <td><input type="checkbox" class="seats" value="L20"></td>
          </tr>
          <tr>
            <td>M</td>
            <td><input type="checkbox" class="seats" value="M1"></td>
            <td><input type="checkbox" class="seats" value="M2"></td>
            <td><input type="checkbox" class="seats" value="M3"></td>
            <td><input type="checkbox" class="seats" value="M4"></td>
            <td><input type="checkbox" class="seats" value="M5"></td>
            <td><input type="checkbox" class="seats" value="M6"></td>
            <td><input type="checkbox" class="seats" value="M7"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="M8"></td>
            <td><input type="checkbox" class="seats" value="M9"></td>
            <td><input type="checkbox" class="seats" value="M10"></td>
            <td><input type="checkbox" class="seats" value="M11"></td>
            <td><input type="checkbox" class="seats" value="M12"></td>
            <td><input type="checkbox" class="seats" value="M13"></td>
            <td><input type="checkbox" class="seats" value="M14"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="M15"></td>
            <td><input type="checkbox" class="seats" value="M16"></td>
            <td><input type="checkbox" class="seats" value="M17"></td>
            <td><input type="checkbox" class="seats" value="M18"></td>
            <td><input type="checkbox" class="seats" value="M19"></td>
            <td><input type="checkbox" class="seats" value="M20"></td>
          </tr>
          <tr>
            <td>N</td>
            <td><input type="checkbox" class="seats" value="N1"></td>
            <td><input type="checkbox" class="seats" value="N2"></td>
            <td><input type="checkbox" class="seats" value="N3"></td>
            <td><input type="checkbox" class="seats" value="N4"></td>
            <td><input type="checkbox" class="seats" value="N5"></td>
            <td><input type="checkbox" class="seats" value="N6"></td>
            <td><input type="checkbox" class="seats" value="N7"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="N8"></td>
            <td><input type="checkbox" class="seats" value="N9"></td>
            <td><input type="checkbox" class="seats" value="N10"></td>
            
            <td><input type="checkbox" class="seats" value="N11"></td>
            <td><input type="checkbox" class="seats" value="N12"></td>
            <td><input type="checkbox" class="seats" value="N13"></td>
            <td><input type="checkbox" class="seats" value="N14"></td>
            <td class="seatGap"></td>
            <td><input type="checkbox" class="seats" value="N15"></td>
            <td><input type="checkbox" class="seats" value="N16"></td>
            <td><input type="checkbox" class="seats" value="N17"></td>
            <td><input type="checkbox" class="seats" value="N18"></td>
            <td><input type="checkbox" class="seats" value="N19"></td>
            <td><input type="checkbox" class="seats" value="N20"></td>
          </tr>
          <br>
            <tr>
            <td colspan="100%"><div class="screen">all eyes this way please</div></td>
            
            
            <br/>
          </tr>
    </table>
    </div>
    
  
<br/>
<button onclick="updateTextArea()" class="btn-successs">Confirm Selection</button>
</center>

<div class="row">
    <div class="col-md-5">
    </div>
    <div class="col-md-2">
        <div class="smallBox greenBox">
            Selected seat
        </div>
         <div class="smallBox redBox">
            Reserved seat
        </div>
        <div class="smallBox emptyBox">
            Empty seat
        </div>
    </div>
    <div class="col-md-5">
    </div>
</div>
      
<br/><br/>

<div class="displayerBoxes">
<center>
  <table class="Displaytable " width="100%" >
  <tr>
    <th>Name</th>
    <th>Number of Seats</th>
    <th>Seats</th>
  </tr>
  <tr>
    <td><textarea id="nameDisplay"></textarea></td>
    <td><textarea id="NumberDisplay"></textarea></td>
    <td><textarea id="seatsDisplay"></textarea></td>
  </tr>
</table>
</center>
</div>
</div>

      <div class="row text-center">
         <hr> <img src="../Assets/backend/images/logoct.png" class="text-center"><hr>
      </div>

<script>

function onLoaderFunc()
{
  $(".seatStructure *").prop("disabled", true);
  $(".displayerBoxes *").prop("disabled", true);
}
function takeData()
{
  if (( $("#Username").val().length == 0 ) || ( $("#Numseats").val().length == 0 ))
  {
  alert("Please Enter your Name and Number of Seats");
  }
  else
  {
    $(".inputForm *").prop("disabled", true);
    $(".seatStructure *").prop("disabled", false);
    document.getElementById("notification").innerHTML = "<b style='margin-bottom:0px;background:yellow;'>Please Select your Seats NOW!</b>";
  }
}


function updateTextArea() { 
    
  if ($("input:checked").length == ($("#Numseats").val()))
    {
      $(".seatStructure *").prop("disabled", true);
      
     var allNameVals = [];
     var allNumberVals = [];
     var allSeatsVals = [];
  
     //Storing in Array
     allNameVals.push($("#Username").val());
     allNumberVals.push($("#Numseats").val());
     $('#seatsBlock :checked').each(function() {
       allSeatsVals.push($(this).val());
     });
    
     //Displaying 
     $('#nameDisplay').val(allNameVals);
     $('#NumberDisplay').val(allNumberVals);
     $('#seatsDisplay').val(allSeatsVals);
    }
  else
    {
      alert("Please select " + ($("#Numseats").val()) + " seats")
    }
  }


function myFunction() {
  alert($("input:checked").length);
}

/*
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
*/


$(":checkbox").click(function() {
  if ($("input:checked").length == ($("#Numseats").val())) {
    $(":checkbox").prop('disabled', true);
    $(':checked').prop('disabled', false);
  }
  else
    {
      $(":checkbox").prop('disabled', false);
    }
});


</script>

</body>
</html>
