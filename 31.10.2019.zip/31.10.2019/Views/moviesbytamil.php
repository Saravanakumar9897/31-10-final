 <!-- Author: Saravana kumar
 description: sorted movies by tamil
  -->
<!DOCTYPE html>
<html>
<head>
	<title>Movie Ticket Booking System</title>
	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/style.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	  <!-- carousel files  -->
		  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	 

</head>
<body>
	<div class="container-fluid">
						<!-- main container starts here -->
		<div class="row">
		<nav class="navbar navbar-inverse navbar-static-top">
									<!-- navbar starts here -->
		  	<div class="container-fluid">
		   		<div class="navbar-header">
			      	<a class="navbar-brand" href="#"><img src="../Assets/backend/images/logoct.png"></a>
			      	<span class="searchbar text-center">
			      	<input type="text" name="" class="searchbar" value="" placeholder="search movies"></span>
			      	<span class="search-btn"><button class="btn search-btn"><span class="glyphicon glyphicon-search "></span></button></span>
		    	</div>
			    <ul class="nav navbar-nav navbar-right">
			      <li class=""><a href="#">Home</a></li>
			      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Tamil <span class="caret"></span></a>
			        <ul class="dropdown-menu active">
			          <li><a href="#" class="active">Tamil</a></li>
			          <li><a href="#">English</a></li>
			          <li><a href="#">Hindi</a></li>
			        </ul>
			      </li>
			      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Chennai <span class="caret"></span></a>
			        <ul class="dropdown-menu">
			          <li><a href="#">Chennai</a></li>
			          <li><a href="#">Vellore</a></li>
			          <li><a href="#">kancheepuram</a></li>
			        </ul>
			      </li>
			      
			      <li>
			      	<div class="container-m menu-icon dropbtn" onclick="myFunction(this)" >
	  					<div class="bar1"></div>
	  					<div class="bar2"></div>
	  					<div class="bar3"></div>
					</div>
					
			      </li>
			    </ul>
			    <div id="myDropdown" class="dropdown-content">
					    <a href="#home">Home</a>
					    <a href="#about"><span class="glyphicon glyphicon-cog">Settings </span> </a>
					    <a href="#contact">Contact</a>
				</div>
			</div>

		</nav>				<!-- navbar ends here  -->
		</div>
		<div class="container">
  
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="item active">
        <img src="../Assets/backend/images/bigil4.jpg" alt="Bigil" style="width:100%;"/>
        
      </div>

      <div class="item">
        <img src="../Assets/backend/images/kaithi1.jpg" alt="Chicago" style="width:100%;">
      </div>
    
      <div class="item">
        <img src="../Assets/backend/images/asuran.jpeg" alt="New york" style="width:100%;">
      </div>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>	




</div>
</div>
</body>
</html>

