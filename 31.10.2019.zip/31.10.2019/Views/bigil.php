
<!-- Author: Saravana kumar
Description: Bigil Movie description page
dated: 30.10.2019 -->






<!DOCTYPE html>
<html lang="en">
<html>
<head>
	<title>Movie Ticket Booking System</title>
	<!-- online cdn -->
	<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script> -->

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- available cdn -->

	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="../Assets/backend/css/style.css">
  <link rel="stylesheet" type="text/css" href="../Assets/backend/css/style1.css">
	<link rel="stylesheet" type="text/javascript" href="../Assets/backend/js/selectseats.js">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	 <!--  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script> -->
	  <!-- carousel link -->
	   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
	

</head>
<body>
	<div class="container-fluid">
		<div class="row">
		<nav class="navbar navbar-inverse navbar-static-top">
                  <!-- navbar starts here -->
       	 <div class="container-fluid">
          <div class="navbar-header">
              <a class="navbar-brand" href="#"><img src="../Assets/backend/images/logoct.png"></a>
              <span class="searchbar text-center">
              <input type="text" name="" class="searchbar" value="" placeholder="search movies"></span>
              <span class="search-btn"><button class="btn search-btn"><span class="glyphicon glyphicon-search "></span></button></span>
          </div>
          <ul class="nav navbar-nav navbar-right">
            <li class="active"><a href="#">Home</a></li>
            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Languages <span class="caret"></span></a>
              <ul class="dropdown-menu">
                <li><a href="#" class="active">Tamil</a></li>
                <li><a href="#">English</a></li>
                <li><a href="#">Hindi</a></li>
              </ul>
            </li>
            <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">Chennai <span class="caret"></span></a>
              <ul class="dropdown-menu">
                
                <li><a href="#">Vellore</a></li>
                <li><a href="#">kancheepuram</a></li>
              </ul>
            </li>
            
            <li>
              <div class="container-m menu-icon dropbtn" onclick="menu(this)" >
              <div class="bar1"></div>
              <div class="bar2"></div>
              <div class="bar3"></div>
          </div>
          
            </li>
          </ul>
          
      </div>

    </nav>        <!-- navbar ends here  -->
</div>
<div class="row">
  <img src="../Assets/backend/images/bigilbannner.jpg" height="700px" width="100%">
</div>
<div class="row">
  <h2>BIGIL</h2>
  <h3>U/A Tamil </h3>
</div><b>
<h5>SYNOPSIS</h5>
</b>
  <p>Bigil portrays Thalapathy Vijay in the role of a coach to the women`s football team. The story depicts his attempts to push them towards success.</p>

<h3>Cast and Crew </h3>
<div class="row">
  <div class="col-md-2 text-center">
    <img src="../Assets/backend/images/actor_vijay.jpg" class="img-circle" width="150px" height="150px">
    <h5> Vijay </h5>
  </div>
  <div class="col-md-2 text-center">
    <img src="../Assets/backend/images/nayan.jpeg" class="img-circle" width="150px" height="150px">
    <h5> Nayanthara </h5>
  </div>
  <div class="col-md-2 text-center">
    <img src="../Assets/backend/images/jackieshroff.jpeg" class="img-circle" width="150px" height="150px">
    <h5> Jackie Shroff </h5>
  </div>
  <div class="col-md-2 text-center">
    <img src="../Assets/backend/images/kathir.jpeg" class="img-circle" width="150px" height="150px">
    <h5> Kathir </h5>
  </div>
  <div class="col-md-2 text-center">
    <img src="../Assets/backend/images/vivek.jpeg" class="img-circle" width="150px" height="150px">
    <h5> Vivek </h5>
  </div>
  <div class="col-md-2 text-center">
    <img src="../Assets/backend/images/yogibabu.jpeg" class="img-circle" width="150px" height="150px">
    <h5> Yogibabu </h5>
  </div>

</div>
<div class="row text-center"><a href="selectseats.php">
  <input type="button" class="btn-success" value="BOOK"></input></a>
</div>

<div class="row text-center">
  <hr>
  <img src="../Assets/backend/images/logoct.png">
  <hr>
</div>





	</div>

</body>
</html>